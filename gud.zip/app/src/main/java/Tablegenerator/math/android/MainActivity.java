package Tablegenerator.math.android;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DialogFragment;
import android.app.Fragment;
import android.app.FragmentManager;
import android.content.*;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;
import android.view.inputmethod.InputMethodManager;

public class MainActivity extends Activity {
	
	private double num = 0;
	private double table = 0;
	private double v = 0;
	private HashMap<String, Object> m = new HashMap<>();
	
	private ArrayList<HashMap<String, Object>> map = new ArrayList<>();
	
	private LinearLayout control_panel;
	private ListView listview1;
	private LinearLayout linear2;
	private Button button1;
	private TextView textview3;
	private EditText no;
	private TextView textview4;
	private EditText max;
	private ImageView imageview1;
	
	private AlertDialog.Builder d;
	private SharedPreferences sp;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		control_panel = findViewById(R.id.control_panel);
		listview1 = findViewById(R.id.listview1);
		linear2 = findViewById(R.id.linear2);
		button1 = findViewById(R.id.button1);
		textview3 = findViewById(R.id.textview3);
		no = findViewById(R.id.no);
		textview4 = findViewById(R.id.textview4);
		max = findViewById(R.id.max);
		imageview1 = findViewById(R.id.imageview1);
		d = new AlertDialog.Builder(this);
		sp = getSharedPreferences("sp", Activity.MODE_PRIVATE);
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				map.clear();
				if (!no.getText().toString().equals("")) {
					num = Double.parseDouble(no.getText().toString());
					if (!max.getText().toString().equals("")) {
						v = Double.parseDouble(max.getText().toString());
						table = 0;
						listview1.setAdapter(new Listview1Adapter(map));
						while(!(v == table)) {
							{
								HashMap<String, Object> _item = new HashMap<>();
								_item.put("", "");
								map.add(_item);
							}
							((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
							table++;
						}
					} else {
						SketchwareUtil.showMessage(getApplicationContext(), "look at your value !!");
					}
				} else {
					SketchwareUtil.showMessage(getApplicationContext(), "look at your value !!");
				}
			}
		});
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				// 1. Use the Builder pattern properly
				AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
				View inflate = getLayoutInflater().inflate(R.layout.search, null);
				builder.setView(inflate);
				
				final AlertDialog dialog1 = builder.create();
				
				// 2. Fix transparency and Focus issues
				if (dialog1.getWindow() != null) {
					dialog1.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
					// This allows the dialog to receive input focus immediately
					dialog1.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM);
					dialog1.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
				}
				
				final EditText edittext1 = inflate.findViewById(R.id.edittext1);
				Button button1 = inflate.findViewById(R.id.button1);
				
				button1.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						String input = edittext1.getText().toString();
						if (!input.isEmpty()) {
							try {
								int position = Integer.parseInt(input);
								listview1.smoothScrollToPosition(position);
								dialog1.dismiss();
							} catch (NumberFormatException e) {
								edittext1.setError("Enter a valid number");
							}
						}
					}
				});
				
				dialog1.show();
				
				// 3. Reliable Keyboard Pop-up
				edittext1.requestFocus();
				edittext1.postDelayed(new Runnable() {
					@Override
					public void run() {
						edittext1.requestFocus();
						android.view.inputmethod.InputMethodManager imm = (android.view.inputmethod.InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
						if (imm != null) {
							imm.showSoftInput(edittext1, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT);
						}
					}
				}, 200);
				
			}
		});
	}
	
	private void initializeLogic() {
		if (sp.getString("f", "").equals("")) {
			sp.edit().putString("f", "1").commit();
			d.setTitle("Dear user");
			d.setMessage("Thank you for downloading this app 🥰.\nidk why but yea. also, this app allows you to generate upto 1.5 million products of certain number if you desire. I have tested this in my phone ( redmi 9A ), & it works without crash !!\nDon't worry this message won't popup again 🙃");
			d.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface _dialog, int _which) {
					
				}
			});
			d.create().show();
		}
	}
	
	public void _tablee() {
		table = Double.parseDouble(max.getText().toString());
		if (!(Double.parseDouble(map.get((int)0).get("maxvalue").toString()) == table)) {
			table++;
			{
				HashMap<String, Object> _item = new HashMap<>();
				_item.put("maxvalue", String.valueOf((long)(table)));
				map.add(_item);
			}
			listview1.setAdapter(new Listview1Adapter(map));
			((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
			SketchwareUtil.showMessage(getApplicationContext(), "shitfr");
		} else {
			SketchwareUtil.showMessage(getApplicationContext(), "shitfruuu");
			{
				HashMap<String, Object> _item = new HashMap<>();
				_item.put("maxvalue", String.valueOf((long)(table)));
				map.add(_item);
			}
			listview1.setAdapter(new Listview1Adapter(map));
			((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
		}
	}
	
	public class Listview1Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.cus, null);
			}
			
			final TextView base_text = _view.findViewById(R.id.base_text);
			final TextView textview3 = _view.findViewById(R.id.textview3);
			final TextView multiplier_text = _view.findViewById(R.id.multiplier_text);
			final TextView textview4 = _view.findViewById(R.id.textview4);
			final TextView result_text = _view.findViewById(R.id.result_text);
			
			base_text.setText(String.valueOf((long)(num)));
			multiplier_text.setText(String.valueOf((long)(_position + 1)));
			result_text.setText(String.valueOf((long)(num * (_position + 1))));
			
			return _view;
		}
	}
}